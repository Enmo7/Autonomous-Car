/*
 * Clock.h
 *
 * Created: 9/30/2022 9:16:36 PM
 *  Author: user
 */ 


#ifndef CLOCK_H_
#define CLOCK_H_

#define F_CPU 16000000UL
#include <util/delay.h>


#endif /* CLOCK_H_ */