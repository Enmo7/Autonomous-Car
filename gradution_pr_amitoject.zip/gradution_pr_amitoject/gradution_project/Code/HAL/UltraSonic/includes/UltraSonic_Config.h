/*
 * UltraSonic_Config.h
 *
 * Created: 1/27/2023 12:35:26 AM
 *  Author: Lenovo
 */ 


#ifndef ULTRASONIC_CONFIG_H_
#define ULTRASONIC_CONFIG_H_

#define EXT_GIFR_REG (*(volatile Uint8 *)0x5A)
#define GIFR_INTF0 6


#endif /* ULTRASONIC_CONFIG_H_ */