/*
 * GINT_HW.h
 *
 * Created: 10/7/2022 10:11:34 PM
 *  Author: user
 */ 


#ifndef GINT_HW_H_
#define GINT_HW_H_

#include "STD_Types.h"

#define SREG_Reg (*(volatile Uint8 *)0x5F)


#endif /* GINT_HW_H_ */